const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const recentResults = [
  { icon: "V", tone: "dark", title: "Visual Studio Code", sub: "最近打开 · NovaHub", type: "应用", key: "↵" },
  { icon: "文", tone: "translate-icon", title: "翻译文本", sub: "NovaHub 官方插件", type: "插件", key: "⌘⇧T" },
  { icon: "⌘", title: "打开插件管理", sub: "NovaHub 设置", type: "命令", key: "" },
  { icon: "N", title: "NovaHub architecture.md", sub: "C:\\user-data\\code\\github\\NovaHub\\docs", type: "文件", key: "" },
  { icon: "C", tone: "folder", title: "C:\\user-data\\code\\github", sub: "最近访问的文件夹", type: "文件夹", key: "" },
  { icon: "42", title: "计算器", sub: "输入算式立即计算", type: "内置", key: "" }
];

const searchResults = [
  { icon: "V", tone: "dark", title: "Visual Studio Code", sub: "Microsoft · 应用程序", type: "应用", key: "↵" },
  { icon: "C", title: "code.exe", sub: "C:\\Users\\cmira\\AppData\\Local\\Programs\\Microsoft VS Code", type: "文件", key: "" },
  { icon: "⌘", title: "在 Code 中打开当前文件夹", sub: "系统命令", type: "命令", key: "" },
  { icon: "N", title: "NovaHub source code", sub: "C:\\user-data\\code\\github\\NovaHub", type: "文件夹", key: "" },
  { icon: "</>", title: "Code Search", sub: "Developer Utilities · 插件", type: "插件", key: "" }
];

let selectedResult = 0;
let actionOpen = false;

function renderResults(items) {
  const list = $("#resultList");
  list.innerHTML = items.map((item, index) => `
    <div class="result-row ${index === selectedResult ? "selected" : ""}" role="option" aria-selected="${index === selectedResult}" data-index="${index}">
      <div class="result-icon ${item.tone || ""}">${item.icon}</div>
      <div class="result-copy"><strong>${item.title}</strong><span>${item.sub}</span></div>
      <div class="result-meta"><span class="result-type">${item.type}</span>${item.key ? `<kbd>${item.key}</kbd>` : ""}</div>
    </div>`).join("");
  $$(".result-row", list).forEach(row => row.addEventListener("mouseenter", () => {
    selectedResult = Number(row.dataset.index);
    renderResults(currentResults());
  }));
}

function currentResults() {
  return $("#launcherSearch").value.trim() ? searchResults : recentResults;
}

function updateLauncher() {
  const hasQuery = Boolean($("#launcherSearch").value.trim());
  $("#resultLabel").textContent = hasQuery ? "最佳匹配" : "最近使用";
  selectedResult = Math.min(selectedResult, currentResults().length - 1);
  renderResults(currentResults());
}

function toggleActions(next = !actionOpen) {
  actionOpen = next;
  $("#actionPanel").classList.toggle("open", actionOpen);
}

function showView(view) {
  $$(".stage").forEach(stage => stage.classList.toggle("hidden", stage.dataset.screen !== view));
  $$(".view-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.view === view));
  if (view === "launcher") setTimeout(() => $("#launcherSearch").focus(), 0);
}

function showToast(id) {
  const toast = $(id);
  toast.classList.remove("hidden");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.add("hidden"), 3200);
}

$$('.view-tab').forEach(tab => tab.addEventListener('click', () => showView(tab.dataset.view)));
$("#themeButton").addEventListener("click", () => document.body.classList.toggle("dark"));
$("#launcherSearch").addEventListener("input", updateLauncher);
$("#launcherSearch").addEventListener("keydown", event => {
  const count = currentResults().length;
  if (event.key === "ArrowDown") { event.preventDefault(); selectedResult = (selectedResult + 1) % count; renderResults(currentResults()); }
  if (event.key === "ArrowUp") { event.preventDefault(); selectedResult = (selectedResult - 1 + count) % count; renderResults(currentResults()); }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); toggleActions(true); }
  if (event.key === "Escape") { if (actionOpen) toggleActions(false); else { event.currentTarget.value = ""; updateLauncher(); } }
});
document.addEventListener("keydown", event => { if (event.key === "Escape" && actionOpen) toggleActions(false); });

function showTranslatorState(state) {
  $("#translatorForm").classList.toggle("hidden", state !== "form");
  $("#translateResult").classList.toggle("hidden", state !== "result");
  $("#pluginError").classList.toggle("hidden", state !== "error");
}

$("#clearTranslate").addEventListener("click", () => { $("#translateInput").value = ""; $("#translateInput").focus(); });
$("#translateButton").addEventListener("click", () => {
  if (!$("#translateInput").value.trim()) { showTranslatorState("error"); return; }
  $("#translatorForm").classList.add("loading");
  $("#translateButton").disabled = true;
  setTimeout(() => { $("#translatorForm").classList.remove("loading"); $("#translateButton").disabled = false; showTranslatorState("result"); }, 650);
});
$("#editTranslation").addEventListener("click", () => showTranslatorState("form"));
$("#errorBack").addEventListener("click", () => showTranslatorState("form"));
$("#retryTranslate").addEventListener("click", () => showTranslatorState("form"));
[$("#copyTranslation"), $("#copyTranslation2")].forEach(button => button.addEventListener("click", async () => {
  try { await navigator.clipboard.writeText("NovaHub keeps every search fast, quiet, and under your control."); } catch (_) { /* local file clipboard may be unavailable */ }
  showToast("#translationToast");
}));

const plugins = [
  { id: "translate", icon: "文", tone: "translate-icon", name: "翻译", sub: "2 个命令 · NovaHub Labs", version: "1.4.2" },
  { id: "json", icon: "{ }", name: "JSON 工具", sub: "3 个命令 · NovaHub Labs", version: "1.1.0" },
  { id: "color", icon: "#", tone: "folder", name: "颜色工具", sub: "2 个命令 · Lumen Studio", version: "0.9.4" }
];

function renderPlugins(items = plugins) {
  $("#pluginCount").textContent = `${items.length} 个插件`;
  $("#pluginList").innerHTML = items.map(plugin => `
    <button class="plugin-list-item" data-plugin="${plugin.id}">
      <div class="plugin-icon ${plugin.tone || ""}">${plugin.icon}</div>
      <div class="plugin-list-copy"><strong>${plugin.name}</strong><span>${plugin.sub}</span></div>
      <div class="plugin-list-meta"><span>v${plugin.version}</span><span class="status-dot"><i></i>已启用</span><svg viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"></path></svg></div>
    </button>`).join("");
  $$(".plugin-list-item").forEach(row => row.addEventListener("click", () => {
    if (row.dataset.plugin === "translate") { $("#pluginListView").classList.add("hidden"); $("#pluginDetail").classList.remove("hidden"); }
  }));
}

$("#pluginSearch").addEventListener("input", event => {
  const query = event.target.value.trim().toLowerCase();
  renderPlugins(plugins.filter(plugin => plugin.name.toLowerCase().includes(query)));
});
$("#backToPlugins").addEventListener("click", () => { $("#pluginDetail").classList.add("hidden"); $("#pluginListView").classList.remove("hidden"); });
$("#pluginEnabled").addEventListener("change", event => { event.target.closest("label").querySelector("em").textContent = event.target.checked ? "已启用" : "已禁用"; });
$("#openUninstall").addEventListener("click", () => $("#uninstallModal").classList.remove("hidden"));
$("#cancelUninstall").addEventListener("click", () => $("#uninstallModal").classList.add("hidden"));
$("#confirmUninstall").addEventListener("click", () => {
  $("#uninstallModal").classList.add("hidden");
  $("#pluginDetail").classList.add("hidden");
  $("#pluginListView").classList.remove("hidden");
  plugins.splice(plugins.findIndex(plugin => plugin.id === "translate"), 1);
  renderPlugins();
  showToast("#uninstallToast");
});

renderResults(recentResults);
renderPlugins();

function applyPrototypeRoute() {
  const params = new URLSearchParams(window.location.search);
  const view = params.get("view") || "launcher";
  const state = params.get("state") || (view === "launcher" ? "idle" : view === "translator" ? "form" : "list");
  if (params.get("theme") === "dark") document.body.classList.add("dark");
  showView(view);

  if (view === "launcher") {
    if (state === "results" || state === "actions") {
      $("#launcherSearch").value = params.get("query") || "code";
      updateLauncher();
    }
    if (state === "actions") toggleActions(true);
  }

  if (view === "translator") {
    if (state === "result") showTranslatorState("result");
    else if (state === "error") showTranslatorState("error");
    else showTranslatorState("form");
  }

  if (view === "plugins") {
    if (state === "detail" || state === "uninstall") {
      $("#pluginListView").classList.add("hidden");
      $("#pluginDetail").classList.remove("hidden");
    }
    if (state === "uninstall") $("#uninstallModal").classList.remove("hidden");
  }
}

applyPrototypeRoute();
